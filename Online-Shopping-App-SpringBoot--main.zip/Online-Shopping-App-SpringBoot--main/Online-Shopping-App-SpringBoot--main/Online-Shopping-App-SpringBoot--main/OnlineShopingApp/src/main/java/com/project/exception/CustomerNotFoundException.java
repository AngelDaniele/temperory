package com.project.exception;

public class CustomerNotFoundException extends RuntimeException {
	
	
	public CustomerNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public CustomerNotFoundException(String messege) {
		
		super(messege);
	}
	
	

}
