package com.project.exception;

public class AddressNotFound extends RuntimeException{
	
	public AddressNotFound() {
		// TODO Auto-generated constructor stub
	}
	
	public AddressNotFound(String message) {
		super(message);
	}

}
