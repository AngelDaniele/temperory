package com.example.scm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplyChainManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplyChainManagementApplication.class, args);
	}

}
