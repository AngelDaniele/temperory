package com.example.scm.service;
import com.example.scm.model.Product;
import com.example.scm.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    ProductRepository productRepository;

    public Product saveProduct(Product product) {

        return productRepository.save(product);

    }

    public List<Product> getAllProduct() {
        return productRepository.findAll();
    }

    public Product getProductByName(String productName) {
        Product product1= productRepository.findByProductName(productName);
        System.out.println(product1);
        return product1;

    }


    public void removeProductById (long productid)
    {
        productRepository.deleteById (productid);


    }
}