package com.example.scm.controller;

import com.example.scm.model.Product;
import com.example.scm.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Product")
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping("/saveProduct")
    public Product saveProudct(@RequestBody Product product)
    {
         return productService.saveProduct(product);

    }


 @GetMapping("/getAllProduct")
    public List<Product> getProducts(){
        return productService.getAllProduct();


    }

    @GetMapping("/{productName}")
    public ResponseEntity<Product> getProductByName(@PathVariable("productName") String productName){
        System.out.println(productName);
        Product tempproduct =productService.getProductByName(productName);
        System.out.println(tempproduct);
       // return new ResponseEntity<Product>(tempproduct, HttpStatus.ACCEPTED);
        if (tempproduct != null) {
            return new ResponseEntity<Product>(tempproduct, HttpStatus.OK);
        } else {
            return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
        }

   }

   @DeleteMapping("/removeProductById/{productid}")
public void removeProduct(@PathVariable("productid") long productid)
{
   productService.removeProductById(productid);


}





}
//    @GetMapping("/getProductByName/{productName}")
//    public Product getProductByName(@PathVariable("productName") String productName){
//        return productService.getProductByName(productName);
//
//    }


//
