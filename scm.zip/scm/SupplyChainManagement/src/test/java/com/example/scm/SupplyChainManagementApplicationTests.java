package com.example.scm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplyChainManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
