package com.inn.scm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplyChainManagement3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
