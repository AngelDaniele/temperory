package com.in.invoice.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
public class TimeSheetEntry {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int TimeSheeetEntryId;

    @ManyToOne
    private Employee employee;

    @ManyToOne
    private Project project;

    LocalDate date;

    LocalTime loginTime;
   LocalTime logoutTime;

    public int getTimeSheeetEntryId() {
        return TimeSheeetEntryId;
    }

    public void setTimeSheeetEntryId(int timeSheeetEntryId) {
        TimeSheeetEntryId = timeSheeetEntryId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(LocalTime loginTime) {
        this.loginTime = loginTime;
    }

    public LocalTime getLogoutTime() {
        return logoutTime;
    }

    public void setLogoutTime(LocalTime logoutTime) {
        this.logoutTime = logoutTime;
    }
}
