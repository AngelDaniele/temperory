package com.in.invoice.service;

import com.in.invoice.model.Admin;
import com.in.invoice.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminRegisterService {

    @Autowired
    AdminRepository adminRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;


    @Autowired
    public AdminRegisterService(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }
    public Admin saveAdmin(Admin admin) {
        Admin admin1 = adminRepository.findByAdminLoginId(admin.getAdminLoginId());
        if (admin1 == null) {
            String enPassWrd = passwordEncoder.encode(admin.getAdminLoginId());
            admin.setAdminPassword(enPassWrd);
            return adminRepository.save(admin);
        } else {
            System.out.println("User Already Exists");
        }

        return admin;
    }


}