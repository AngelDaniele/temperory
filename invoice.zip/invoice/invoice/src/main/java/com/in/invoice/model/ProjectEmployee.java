package com.in.invoice.model;

import javax.persistence.*;

@Entity
public class ProjectEmployee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int proEmpEntryId;

    @ManyToOne
    private Project project;

    @ManyToOne
    private Employee employee;

    private int billingRate;

    public int getProEmpEntryId() {
        return proEmpEntryId;
    }

    public void setProEmpEntryId(int proEmpEntryId) {
        this.proEmpEntryId = proEmpEntryId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public int getBillingRate() {
        return billingRate;
    }

    public void setBillingRate(int billingRate) {
        this.billingRate = billingRate;
    }
}
