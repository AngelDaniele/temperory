package com.in.invoice.controller;

import com.in.invoice.model.Admin;
import com.in.invoice.service.AdminRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
//@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/Admin")
public class AdminController {

    @Autowired
    AdminRegisterService adminRegisterService;

    @PostMapping("/saveAdmin")
    public ResponseEntity<Admin> saveAdmin(@RequestBody Admin admin) {
        Admin responseAdmin =  adminRegisterService.saveAdmin(admin);
        return new  ResponseEntity<Admin>(responseAdmin, HttpStatus.CREATED);
    }

}
