package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.ClientNotFoundException;
import com.in.generateinvoice.model.Client;
import com.in.generateinvoice.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.List;

@Service
public class ClientService {
    @Autowired
    ClientRepository clientRepository;


    public Client saveClient(Client client) {
        // TODO Auto-generated method stub

        return clientRepository.save(client);

    }

    public List<Client> getAllClient() {
        // TODO Auto-generated method stub
        List<Client> list = clientRepository.findAll();

        if (list.size() > 0) {
            return list;
        } else
            throw new ClientNotFoundException("No Client in catalog");
    }



    public Client updateProductInCatalog(Client client, int key) throws ClientNotFoundException {
        Optional<Client> optionalProduct = clientRepository.findById(key);

        if (optionalProduct.isPresent()) {
            Client existingClient = optionalProduct.get();
            existingClient.setClientId(client.getClientId());
            existingClient.setClientName(client.getClientName());
            existingClient.setClientAddress(client.getClientAddress());
            existingClient.setPhoneNumber(client.getPhoneNumber());
            existingClient.setGmailId(client.getGmailId());

            Client updatedClient = clientRepository.save(existingClient);
            return updatedClient;
        } else {
            throw new ClientNotFoundException("Product not found with the given id");
        }
    }


    public String deleteClient(Integer id) throws ClientNotFoundException {

        Optional<Client> opt=	clientRepository.findById(id);

        if(opt.isPresent()) {
            Client client = opt.get();
            clientRepository.delete(client);
            return "Client deleted";
        } else
            throw new ClientNotFoundException("Client not found with given id");
    }


    public Client getClientById(Integer clientTableId) {
        Optional<Client> opt = clientRepository.findById(clientTableId);
        if (opt.isPresent()) {
            return opt.get();
        }

        else
            throw new ClientNotFoundException("Client not found with given id");
    }



}
