package com.in.generateinvoice.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "SubProject")

public class SubProject {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "subProjectTableId")
    private int subProjectTableId;

    @Column(name = "subProjectId")
    private String subProjectId;

    @Column(name = "startDate")
    private LocalDate startDate;

    @Column(name = "endDate")
    private LocalDate endDate;

    @Column(name = "budget")
    private int budget;

    @ManyToOne
    @JoinColumn(name = "projectTableId")
    private Project project;

    // Constructors, getters, and setters

    public SubProject() {
    }

    public SubProject(String subProjectId, LocalDate startDate, LocalDate endDate, int budget, Project project) {
        this.subProjectId = subProjectId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.budget = budget;
        this.project = project;
    }

    // Add getters and setters for all fields

    public int getSubProjectTableId() {
        return subProjectTableId;
    }

    public void setSubProjectTableId(int subProjectTableId) {
        this.subProjectTableId = subProjectTableId;
    }

    public String getSubProjectId() {
        return subProjectId;
    }

    public void setSubProjectId(String subProjectId) {
        this.subProjectId = subProjectId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public int getBudget() {
        return budget;
    }

    public void setBudget(int budget) {
        this.budget = budget;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }


}










