package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.SubProject;
import com.in.generateinvoice.model.SubProjectUI;
import com.in.generateinvoice.service.SubProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/subprojects")
public class SubProjectController {




        @Autowired
        private SubProjectService subProjectService;

        @PostMapping("/save")
        public ResponseEntity<SubProject> saveSubProjectUI(@RequestBody SubProjectUI subProjectUI) {
            SubProject savedSubProject = subProjectService.saveSubProjectUIWithAutoUpdate(subProjectUI);
            return ResponseEntity.ok(savedSubProject);
        }
    }






