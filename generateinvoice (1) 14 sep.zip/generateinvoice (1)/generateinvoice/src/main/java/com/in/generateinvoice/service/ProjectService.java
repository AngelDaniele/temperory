package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.ClientNotFoundException;
import com.in.generateinvoice.exception.ProjectNotFoundException;
import com.in.generateinvoice.model.Client;
import com.in.generateinvoice.model.Project;
import com.in.generateinvoice.model.ProjectWithClientIdRequest;
import com.in.generateinvoice.repository.ClientRepository;
import com.in.generateinvoice.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {


    @Autowired
    ProjectRepository projectRepository;

    @Autowired
    ClientRepository clientRepository;


    public Project saveProjectWithClientId(ProjectWithClientIdRequest request, String clientId) {

        Client client = clientRepository.findByClientId(clientId);

        if (client == null) {
            throw new ClientNotFoundException("Client not found for clientId: " + clientId);
        }


        Project project = new Project();
        project.setProjectId(request.getProjectId());
        project.setProjectName(request.getProjectName());
        project.setStartDate(request.getStartDate());
        project.setEndDate(request.getEndDate());
        project.setBudget(request.getBudget());
        project.setClient(client);


        return projectRepository.save(project);
    }


    public List<Project> getAllProject() {

        List<Project> list = projectRepository.findAll();

        if (list.size() > 0) {
            return list;
        } else
            throw new ProjectNotFoundException("No Project in catalog");
    }


}
