package com.in.generateinvoice.model;

import javax.persistence.*;

@Entity
@Table(name="Employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="employeeTableId")
    private int employeeTableId;

    @Column(name="employeeId")
    private String employeeId;
    @Column(name="employeeName")
    private String employeeName;
    @Column(name="designation")
    private String designation;
    @Column(name="technology")
    private String technology;
    @Column(name="address")
    private String address;
    @Column(name="educationalQualification")
    private String educationalQualification;

    public int getEmployeeTableId() {
        return employeeTableId;
    }

    public void setEmployeeTableId(int employeeTableId) {
        this.employeeTableId = employeeTableId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEducationalQualification() {
        return educationalQualification;
    }

    public void setEducationalQualification(String educationalQualification) {
        this.educationalQualification = educationalQualification;
    }
}
