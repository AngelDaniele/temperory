package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.Employee;
import com.in.generateinvoice.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;



    @PostMapping("/saveemployee")
    public Employee saveClient(@RequestBody Employee employee) {

        return employeeService.saveEmployee(employee);
    }

    @GetMapping("/allemployee")
    public List<Employee> getAllemployee(){

        return employeeService.getAllEmployee();
    }

    @PutMapping("/updateemployee/{key}")
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee, @PathVariable int key) {

        Employee employee1 = employeeService.updateEmployee(employee,key);

        return new ResponseEntity<Employee>(employee1, HttpStatus.OK);

    }

    @DeleteMapping("/deleteemployee/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("id") Integer id) {

        String res = employeeService.deleteEmployee(id);
        return new ResponseEntity<String>(res, HttpStatus.OK);

    }

}
