export class Admin {
    id!: number;
    name!: string;
    contactNumber!: string;
    email!: string;
    password!: string;

    constructor(){

    }
}
