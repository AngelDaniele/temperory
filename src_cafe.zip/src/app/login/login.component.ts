import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SignUpService } from '../sign-up.service';
import { Admin } from '../admin';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{

   admin = new Admin();
  service: any;
  

  constructor(private_service:SignUpService){}
  ngOnInit(){
    this.service.loginUserFromRemote();
  }
  


  loginAdmin(){
    this.service.loginAdminFromRemote(this.admin).subscribe(
    (data: any) =>{console.log("response received",data)},
    (error: any) =>{console.log("exception occured",error)}


    );
  
  }
 
}


  
