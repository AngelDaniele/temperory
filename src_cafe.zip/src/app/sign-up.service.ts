import { Injectable } from '@angular/core';
import { Admin } from './admin';
import {HttpClient} from '@angular/common/http';
import { Observable, observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SignUpService {
  [x: string]: any;

  constructor(private _http:HttpClient) { }

  loginAdminFromRemote(admin:Admin):Observable<any>
  {
    return this._http.post<any>("localhost:8081/loginAdmin",admin)

  }
}
