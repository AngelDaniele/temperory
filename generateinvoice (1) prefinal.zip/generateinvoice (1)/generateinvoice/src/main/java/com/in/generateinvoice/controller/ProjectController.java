package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.Project;
import com.in.generateinvoice.model.ProjectWithClientIdRequest;
import com.in.generateinvoice.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/project")
public class ProjectController {
    @Autowired
    ProjectService projectService;


    @PostMapping("/saveproject")
    public ResponseEntity<Project> createProjectWithClientId(
            @RequestBody ProjectWithClientIdRequest request) {
        String clientId = request.getClientId();
        Project savedProject = projectService.saveProjectWithClientId(request, clientId);
        return new ResponseEntity<>(savedProject, HttpStatus.CREATED);
    }

    @GetMapping("/allproject")
    public List<Project> getAllproject(){

        return projectService.getAllProject();
    }






}
