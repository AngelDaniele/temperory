package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.SubProject;
import com.in.generateinvoice.model.SubProjectUI;
import com.in.generateinvoice.service.SubProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/subprojects")
public class SubProjectController {




        @Autowired
        private SubProjectService subProjectService;

        @PostMapping("/save")
        public ResponseEntity<SubProject> saveSubProjectUI(@RequestBody SubProjectUI subProjectUI) {
            SubProject savedSubProject = subProjectService.saveSubProjectUIWithAutoUpdate(subProjectUI);
            return ResponseEntity.ok(savedSubProject);
        }

    @GetMapping("/all")
    public ResponseEntity<List<SubProject>> getAllSubProjects() {
        List<SubProject> subProjects = subProjectService.getAllSubProjects();
        return ResponseEntity.ok(subProjects);
    }
    }






