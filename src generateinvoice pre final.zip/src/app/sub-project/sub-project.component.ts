import { Component, OnInit } from '@angular/core';
import { SubProjectUIS } from './SubProjectUI';
import { SubProjectService } from '../sub-project.service';
import { Router } from '@angular/router';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-sub-project',
  templateUrl: './sub-project.component.html',
  styleUrls: ['./sub-project.component.css']
})
export class SubProjectComponent implements OnInit{
  ngOnInit(): void {
    this.getProjectList();
  }
  
  subProjectUI: SubProjectUIS = new SubProjectUIS("",new Date(),new Date(),0,"");
  projects:any;
  loginFailed = false;
  constructor(private subProjectService: SubProjectService, private router: Router,private projectService: ProjectService) { }
   
  onSubmit() {
    console.log(this.subProjectUI);
    this.saveSubProject();
  }

  saveSubProject() {
    this.subProjectService.createSubProject(this.subProjectUI).subscribe(
      data => {
        console.log(data);
       this.goToSubProjectList();
      },
      error => {
        console.log(error);
         this.loginFailed = true;
      }
    );

}
goToSubProjectList(){

  this.router.navigate(['/subprojectlist']);

}
getProjectList(): void {
  this.projectService.getProjectList().subscribe(projects => this.projects = projects);
}

}
