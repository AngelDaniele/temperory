import { Component, OnInit } from '@angular/core';
 
import { ProjectService } from '../project.service';
import { Router } from '@angular/router';
import { ProjectClients } from 'src/ProjectClient';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit{

  projectclient: ProjectClients = new ProjectClients("", "","","", 0, "");
  clients:any;

  loginFailed = false;
  constructor(private projectService: ProjectService, private router: Router,private clientService: ClientService) { }
  ngOnInit(): void {
    this.getClientList();
  }

  getClientList(): void {
    this.clientService.getClientList().subscribe(clients => this.clients = clients);
  }
  
  onSubmit() {
    console.log(this.projectclient);
    this.saveProject();

  }

  saveProject() {
    this.projectService.createProject(this.projectclient).subscribe(
      data => {
        console.log(data);
        this.goToProjectList();
      },
      error => {
        console.log(error);
        this.loginFailed = true;
      }
    );

}



goToProjectList() {
  this.router.navigate(['/projectlist']);
}


navigateToOtherComponent() {
  this.router.navigate(['/subproject']); // Replace 'other-component' with the actual route path of the other component you want to navigate to
}


}