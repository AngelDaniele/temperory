import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employees } from './Employee';
import { Observable } from 'rxjs';
import { UpdateEmployee } from './UpdateEmployee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employee:any;

  constructor(private http: HttpClient) { }


  createEmployee(employee: Employees): Observable<any> {
    return this.http.post("http://localhost:8080/employee/saveemployee", employee);
  }

  
  getEmployeeList(): Observable<any> {
    return this.http.get("http://localhost:8080/employee/allemployee");
  }




  updateEmployee(employeeTableId: number, employee: UpdateEmployee): Observable<any> {
    return this.http.put<Employees>(`http://localhost:8080/employee/updateemployee/${employeeTableId}`,employee);
  }

  deleteEmployee(employeeTableId: number): Observable<Object> {
    return this.http.delete(`http://localhost:8080/employee/deleteemployee/${employeeTableId}`);
  }



}
