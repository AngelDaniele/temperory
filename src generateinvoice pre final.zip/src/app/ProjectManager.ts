export class ProjectManager {
    
    projectManagerEntryId!:number;
    projectManagerLoginId!: string;
    projectManagerName!: string;
    projectManagerPassword!: string;
   

}

   
