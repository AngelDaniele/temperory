import { Component, OnInit } from '@angular/core';
import { Login } from '../Login';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  login: Login=new Login("","");
  loginFailed = false;
  constructor(private loginService:LoginService,private route:Router) { }

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }


  adminLogin() {
    console.log("ProjectManager component");
    
    this.loginService.LoginService(this.login).subscribe(
      data => {
        console.log(data);
        
        this.route.navigate(['/ProjectManager']);
        
      },
      error => {
        console.error(error);
        this.loginFailed = true;
       
      }
    );
  }


}
