import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProjectClients } from 'src/ProjectClient';
import { SubProjectUIS } from './sub-project/SubProjectUI';

@Injectable({
  providedIn: 'root'
})
export class SubProjectService {

  constructor(private http: HttpClient) { }


  createSubProject(subProjectUI: SubProjectUIS): Observable<any> {
    return this.http.post("http://localhost:8080/subprojects/save", subProjectUI);
  }

  getAllSubProject(): Observable<any>{
    return this.http.get("http://localhost:8080/subprojects/all");
  }
}
