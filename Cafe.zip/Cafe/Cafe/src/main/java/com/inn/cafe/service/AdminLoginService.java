package com.inn.cafe.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.cafe.model.Admin;
import com.inn.cafe.repository.AdminLoginRepository;
@Service
public class AdminLoginService {
  
	
	
	@Autowired
	AdminLoginRepository adminLoginRepository;
	
	public Admin saveAdmin(Admin admin)
	{
		return adminLoginRepository.save(admin);
	}
	
	
	
	public Admin fetchUserByEmailId(String email) {
		return adminLoginRepository.findByEmail(email);

	
	}
	
	
	public Admin findByEmailPassword(String email, String password)
	{
		return adminLoginRepository.findByEmailAndPassword(email,password);
		
	}
	
}
