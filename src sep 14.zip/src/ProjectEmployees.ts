import { Projects } from "./Project";
import { Employees } from "./app/Employee";

export class ProjectEmployees {

    projectEmployeeId!:number;
    employee!: Employees;
    project !:Projects;
    
}

