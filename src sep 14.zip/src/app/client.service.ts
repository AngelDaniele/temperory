import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Clients } from 'src/Client';
import { updateClient } from './updateclient/UpdateClient';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  client:any;
  
  constructor(private http: HttpClient) { }




  createClient(client: Clients): Observable<any> {
    return this.http.post("http://localhost:8080/client/saveclient", client);
  }

  getClientList(): Observable<any> {
    return this.http.get("http://localhost:8080/client/allclient");
  }


  updateClient(clientTableId: number, client: updateClient): Observable<any> {
    return this.http.put<Clients>(`http://localhost:8080/client/updateclient/${clientTableId}`,client);
  }


getClientById(clientTableId: number): Observable<Clients> {
  return this.http.get<Clients>(`http://localhost:8080/client/client/${clientTableId}`);
}

deleteClient(clientTableId: number): Observable<Object> {
  return this.http.delete(`http://localhost:8080/client/deleteclient/${clientTableId}`);
}
  

}
