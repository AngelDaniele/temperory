import { Component } from '@angular/core';
import { SubProjectUIS } from './SubProjectUI';
import { SubProjectService } from '../sub-project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sub-project',
  templateUrl: './sub-project.component.html',
  styleUrls: ['./sub-project.component.css']
})
export class SubProjectComponent {

  subProjectUI: SubProjectUIS = new SubProjectUIS("",new Date(),new Date(),0,"");

  constructor(private subProjectService: SubProjectService, private router: Router) { }
   
  onSubmit() {
    console.log(this.subProjectUI);
    this.saveSubProject();
  }

  saveSubProject() {
    this.subProjectService.createSubProject(this.subProjectUI).subscribe(
      data => {
        console.log(data);
        // this.goToProjectList();
      },
      error => {
        console.log(error);
        // this.loginFailed = true;
      }
    );

}
}
