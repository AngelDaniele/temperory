import { Injectable } from '@angular/core';
import { ProjectManager } from './ProjectManager';
import { Observable } from 'rxjs';
import { Login } from './Login';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  

  constructor(private http:HttpClient) { }




  public LoginService(login:Login): Observable<ProjectManager>{
    return this.http.post<ProjectManager>("http://localhost:8080/ProjectManager/login",login);
  }
}
