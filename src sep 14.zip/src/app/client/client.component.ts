import { Component } from '@angular/core';

import { ClientService } from '../client.service';
import { Router } from '@angular/router';
import { Clients } from 'src/Client';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent {
  client: Clients = new Clients();
 


  constructor(private clientService: ClientService, private router: Router) { }

  onSubmit() {
    console.log(this.client);
    this.saveClient();
  }


  saveClient() {
    this.clientService.createClient(this.client).subscribe(
      data => {
        console.log(data);
        this.goToClientList();
      },
      error => {
        console.log(error);
      }
    );
  }



  goToClientList() {
    this.router.navigate(['/clientlist']);
  }

}
