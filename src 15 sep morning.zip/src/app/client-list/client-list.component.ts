import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})
export class ClientListComponent implements OnInit{

  clients:any;


  constructor(private clientService: ClientService, private router: Router) { }
  ngOnInit(): void {
    this.getClientList();
  }



  getClientList(): void {
    this.clientService.getClientList().subscribe(clients => this.clients = clients);
  }

  updateClient(clientTableId: number): void {
    this.router.navigate(['/updateclient', clientTableId]);
  }

 deleteClient(clientTableId: number): void {
   this.clientService.deleteClient(clientTableId).subscribe(() => {
    this.clients = this.clients.filter((client: any) => client.clientTableId !== clientTableId);
    this.getClientList();
    });
  }


  
goToClientList(): void {
  this.router.navigate(['/clientlist']);
}


  

}
