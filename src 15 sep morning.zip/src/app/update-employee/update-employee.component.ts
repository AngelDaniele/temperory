import { Component, OnInit } from '@angular/core';
import { UpdateEmployee } from '../UpdateEmployee';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  employeeTableId: number = 0;
  employee: UpdateEmployee = new  UpdateEmployee ();


  constructor(private route: ActivatedRoute,private employeeService: EmployeeService, private router: Router) { }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.employeeTableId = +params['employeeTableId'];
      // this.employeeService.getEmployeeById(this.employeeTableId).subscribe(data => {
      //   this.employee = data;
      // });
    });
    
  }

  
onSubmit(): void {
  this.employeeService.updateEmployee(this.employeeTableId, this.employee).subscribe(data=>{
    console.log("Employee updated");
    this.goToEmployeeList();
  });
}

goToEmployeeList(): void {
  this.router.navigate(['/employeelist']);
}


}
