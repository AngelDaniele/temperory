export class Login{
    constructor(
     
      public projectManagerLoginId:string,
      public projectManagerPassword:string
      
    ) {}
  }
  