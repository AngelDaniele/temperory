import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { updateClient } from './UpdateClient';
import { Clients } from 'src/Client';
import { UpdateClient } from '../client/updateClient';

@Component({
  selector: 'app-updateclient',
  templateUrl: './updateclient.component.html',
  styleUrls: ['./updateclient.component.css']
})
export class UpdateclientComponent implements OnInit{
  clientTableId: number = 0;
  client: UpdateClient = new  UpdateClient();

  
constructor(private route: ActivatedRoute,private clientService: ClientService, private router: Router) { }
   ngOnInit(): void {
    this.clientTableId = this.route.snapshot.params['clientTableId'];
   this.getClientById(this.clientTableId);
   this.clientService.getClientById(this.clientTableId).subscribe(data=>{
      this.client = data;});
}



   
  getClientById(clientTableId: number): void {
    this.clientService.getClientById(clientTableId).subscribe(data => {
      this.client = data;
    });
  }



onSubmit(): void {
  this.clientService.updateClient(this.clientTableId, this.client).subscribe(data=>{
    console.log("Client updated");
    this.goToClientList();
  });
}

goToClientList(): void {
  this.router.navigate(['/clientlist']);
}

  }

  

  

