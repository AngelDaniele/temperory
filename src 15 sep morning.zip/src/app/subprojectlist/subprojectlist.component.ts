import { Component } from '@angular/core';
import { SubProjectService } from '../sub-project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-subprojectlist',
  templateUrl: './subprojectlist.component.html',
  styleUrls: ['./subprojectlist.component.css']
})
export class SubprojectlistComponent {

  subProjectUIs:any;

  constructor(private subprojectService: SubProjectService, private router: Router) { }
ngOnInit(): void {
  this.getSubProjectList();
}

  getSubProjectList(): void {
    this.subprojectService.getAllSubProject().subscribe(subProjectUIs => this.subProjectUIs= subProjectUIs);
  }

}
