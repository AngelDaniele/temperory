import { Projects } from "src/Project";


export class SubProjects {

    
    subProjectTableId!:number;
    subProjectId!: string;
    startDate!: string;
    endDate!: Date;
    budget!:number;
    project!: Projects;
    
    

}