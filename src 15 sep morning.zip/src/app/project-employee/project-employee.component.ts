import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { ProjectService } from '../project.service';
import { EmployeeService } from '../employee.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProjectEmployeesUI } from 'src/ProjectEmployeeUI';
import { ProjectEmployeeService } from '../project-employee.service';



@Component({
  selector: 'app-project-employee',
  templateUrl: './project-employee.component.html',
  styleUrls: ['./project-employee.component.css']
})
export class ProjectEmployeeComponent implements OnInit{
 


 


  projectemployeeUI:ProjectEmployeesUI = new ProjectEmployeesUI("","");


  projects:any;
  employees:any;

  constructor(private projectService: ProjectService,private employeeService: EmployeeService, private router: Router,  private projectEmployeeService:ProjectEmployeeService,    private fb: FormBuilder ) { }

  ngOnInit(): void {
    this.getProjectList();
    this.getEmployeeList();

  

  }
  
    getProjectList(): void {
      this.projectService.getProjectList().subscribe(projects => this.projects = projects);
    }

    getEmployeeList(): void {
      this.employeeService.getEmployeeList().subscribe(employees => this.employees = employees);
    }

   
  onSubmit() {
    console.log(this.projectemployeeUI);
    this.saveClient();
   
  
  }


  saveClient() {
    this.projectEmployeeService.saveProjectEmployee(this.projectemployeeUI).subscribe(
      data => {
        console.log(data);
        this.goToProjectEmployeeList();
       
      },
      error => {
        console.log(error);
      }
    );
  }


  goToProjectEmployeeList() {
    this.router.navigate(['/projectemployeelist']);
  }

  }
  
  

  


