import { Clients } from "./Client";

export class Projects {

    
    projectTableId!:number;
    projectId!: string;
    projectName!: string;
    startDate!: Date;
    endDate!: Date;
    client!: Clients;
    budget!:number;
    

}


  
 